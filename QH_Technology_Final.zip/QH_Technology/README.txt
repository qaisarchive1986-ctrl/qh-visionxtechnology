QH Technology - Social Links
==============================

Files:
- index.html  -> complete HTML/CSS/JavaScript page
- logo.png    -> supplied QH Technology logo

How to use:
1. Keep index.html and logo.png in the same folder.
2. Open index.html in a browser.
3. Upload both files to your web host.

Each of the 32 icons is clickable and opens its configured social-service URL in a new browser tab.
The layout is responsive for desktop, tablet, and mobile.
